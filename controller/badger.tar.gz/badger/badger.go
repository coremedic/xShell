package main

import "badger/evasion"

func main() {
	evasion.Debug()
}
